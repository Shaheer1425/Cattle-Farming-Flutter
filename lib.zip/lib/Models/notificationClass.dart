class NotificationRecord {
  final String notificationName;
  final String notification;

  NotificationRecord({
    required this.notificationName,
    required this.notification,
  });
}
