class OtherFarmRecord {
  final String FarmName;
  final String managerName;
  final String contact;
  final int totalCattles;

  OtherFarmRecord({
    required this.FarmName,
    required this.managerName,
    required this.contact,
    required this.totalCattles,
  });
}
