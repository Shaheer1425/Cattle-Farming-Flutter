class FodderStockRecord {
  final String foodName;
  final String date;
  final int qty;
  final int price;

  FodderStockRecord(
      {required this.foodName,
      required this.date,
      required this.qty,
      required this.price});
}
